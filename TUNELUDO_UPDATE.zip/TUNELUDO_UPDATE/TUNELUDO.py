from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.firefox.firefox_profile import FirefoxProfile #Iniciar Perfil cache limpo
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
import paramiko
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from sshtunnel import SSHTunnelForwarder
from paramiko import SSHClient
import time
from datetime import datetime
import os
from selenium.webdriver.support import expected_conditions as EC
import tkinter as tk
from datetime import datetime
from tkinter.ttk import *
from tkinter import *
import re



log = open("acessao.txt",'a')
ie_options = webdriver.IeOptions()
ie_options.attach_to_edge_chrome = True
ie_options.edge_executable_path = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"
internet_explorer = webdriver.Ie(options=ie_options)

def carregar_postos(arquivo):
    postos = open(arquivo,'r',encoding='UTF-8')
    lista_postos = postos.read()
    lista_postos = lista_postos.split('\n')

    for postos in lista_postos:

        def _waitForAlert(driver):
            return WebDriverWait(driver, 120).until(EC.alert_is_present())

        ip = postos

        log.write(datetime.now().strftime('%d/%m/%Y %H:%M:%S') + " Iniciando configuração no posto: " + str(ip) + '\n')
        print("Iniciando configuração do posto: " + str(ip))

        try:
            class SSH:
                def __init__(self):
                    self.ssh = SSHClient()
                    self.ssh.load_system_host_keys()
                    self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    self.ssh.connect(hostname= str(ip),port='22',username='pi',password='SemParar')

            hondian = SSHTunnelForwarder(
                str(ip),
                ssh_username="pi",
                ssh_password="SemParar",
                remote_bind_address=('192.168.8.1',80),
                local_bind_address=('127.0.0.1',5555)
                )
            
            hondian.start()

            vpar1 = SSHTunnelForwarder(
                str(ip),
                ssh_username="pi",
                ssh_password="SemParar",
                remote_bind_address=('192.168.212.41',80),
                local_bind_address=('127.0.0.1',5556)
                )
            
            vpar1.start()

            vpar2 = SSHTunnelForwarder(
                str(ip),
                ssh_username="pi",
                ssh_password="SemParar",
                remote_bind_address=('192.168.212.42',80),
                local_bind_address=('127.0.0.1',5557)
                )
            
            vpar2.start()
        
            

            print('Iniciando configuração Saturno3...')

            log.write(datetime.now().strftime('%d/%m/%Y %H:%M:%S') + " Abrindo pagina da internet " + '\n')
            print(" Abrindo pagina da internet " + str(ip))
            

            driver = webdriver.Edge()

           

            wait = WebDriverWait(driver, 300)

            driver.get('http://127.0.0.1:5555')
            
            try:

                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="login_user"]/div[2]/input')).click()
                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="login_user"]/div[2]/input')).send_keys('admin')
                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="login_passwd"]/div[2]/input')).click()
                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="login_passwd"]/div[2]/input')).send_keys('@bast3ce')
                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="contents1"]/form/div/input')).click()

            except:
                def _waitForAlert(driver):
                 return WebDriverWait(driver, 5).until(EC.alert_is_present())
                alert = _waitForAlert(driver)
                value = alert.text
                print(value)
                alert.accept()
                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="login_user"]/div[2]/input')).click()
                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="login_user"]/div[2]/input')).send_keys('abastece')
                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="login_passwd"]/div[2]/input')).click()
                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="login_passwd"]/div[2]/input')).send_keys('@bast3ce')
                WebDriverWait(driver, timeout=120).until(lambda d: d.find_element(By.XPATH,'//*[@id="contents1"]/form/div/input')).click()



                
            
            time.sleep(600)







            internet_explorer.get('http://127.0.0.1:5556')
            internet_explorer.get('http://127.0.0.1:5557')
            
        except:
            log.write(datetime.now().strftime('%d/%m/%Y %H:%M:%S') + " Erro na configuração do posto: " + str(ip) + '\n')
            print("Erro na configuração do posto: " + str(ip))



'''
helpmenu1 = Menu(menubar, tearoff=0)
helpmenu1.add_command(label = "Selecionar", command = selecionar)
menubar.add_cascade(label = "Navegador", menu = helpmenu1)
'''

    

carregar_postos('postos.txt')