import requests
import os
import ssl
import certifi
from urllib.request import urlopen
import wget


url = "https://github.com/gustavocoutinhooliveira/Acesso_F-cil/blob/main/txt.txt"
filename = wget.download(url)
#urlopen(url, context=ssl.create_default_context(cafile=certifi.where()))
#r = requests.get(url)ccle
#open("TUNELUDO_TESTE.txt", "wb").write(r.content)
#os.startfile("TUNELUDO_TESTE.txt")